#include <stdio.h>

int main() {
    printf("%s\n", "Bye World!");
    return 0;
}