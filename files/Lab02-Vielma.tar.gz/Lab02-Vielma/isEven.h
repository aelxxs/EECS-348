#ifndef ISEVEN_H
#define ISEVEN_H
int isEven(int num);

#endif
