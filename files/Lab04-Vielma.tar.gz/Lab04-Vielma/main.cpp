#include "matrix.h"
#include <stdio.h>
#include <iostream>
int main(){
	int option = 0;
	int num = 0;
	int r = 0;
	int c = 0;

	std::cout<<"\n1. Print the Matrix";
	std::cout<<"\n2. Perform an addition of the matrix with itself";
	std::cout<<"\n3. Get the maximum value in the matrix";
	std::cout<<"\n4. Find whether an element exists in the matrix";
	std::cout<<"\n5. Change an existing element in the matrix";
	std::cout<<"\n6. Perform matrix multiplication";
	std::cout<<"\n7. Transpose of a matrix";
	std::cout<<"\nWhich operations would you like to perform on the matrix: ";
	std::cin>>option;

	matrix m1;
	m1.createMatrix();

	switch(option) {
		case 1:
			m1.printMatrix();
			break;
		case 2:
			m1.addMatrix();
			break;
		case 3:
			std::cout << m1.getMax();
			std::cout << "\n";
			break;
		case 4:
			std::cout << "Enter the number to find: ";
			std::cin >> num;
			m1.findElement(num);
			break;
		case 5:
			std::cout << "Enter the row of the element to change: ";
			std::cin >> r;
			std::cout << "Enter the column of the element to change: ";
			std::cin >> c;
			std::cout << "Enter the value to replace: ";
			std::cin >> num;
			m1.changeElement(r, c, num);
			m1.printMatrix();
			break;
		case 6:
			m1.multiplyMatrix();
			break;
		case 7:
			m1.transposeMatrix();
			break;
		default:
			std::cout << "Not a valid entry. Try again.";
			break;
	}

	return 0;
}
