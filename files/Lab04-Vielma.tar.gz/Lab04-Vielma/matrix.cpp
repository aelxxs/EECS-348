#include <stdio.h>
#include <fstream>
#include <iostream>
#include "matrix.h"

void matrix::createMatrix() {
    std::ifstream file;

    file.open("input.txt");

    file >> rows;
    file >> cols;

    grid = new double * [rows];
    temp = new double * [rows];

    for (int i = 0; i < rows; i++) {
        grid[i] = new double[cols];
        temp[i] = new double[cols];
    }

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            file >> grid[i][j];
        }
    }

    return;
}

void matrix::printMatrix() {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            std::cout << grid[i][j] << "\t";
        }

        std::cout << "\n";
    }
}

void matrix::addMatrix() {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            temp[i][j] = grid[i][j] + grid[i][j];
        }
    }

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            std::cout << temp[i][j] << "\t";
        }

        std::cout << "\n";
    }
}

double matrix::getMax() {
    double max_element = 0;

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (grid[i][j] > max_element) {
                max_element = grid[i][j];
            }
        }
    }

    return max_element;
}

bool matrix::findElement(int no) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (grid[i][j] == no) {
                std::cout << "\nElement found at " << i << ", " << j << "\n";
                return true;
            }
        }
    }

    std::cout << "\nElement not found\n";

    return false;
}

void matrix::changeElement(int r, int c, int no) {
    if (r < rows && c < cols) {
        grid[r][c] = no;

        std::cout << "\nElement changed\n";
    } else {
        std::cout << "\nInvalid row or column\n";
    }

    return;
}
void matrix::multiplyMatrix() {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            float sum = 0;

            for (int k = 0; k < cols; k++) {
                sum += grid[i][k] * grid[k][j];
            }

            temp[i][j] = sum;
        }
    }

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            std::cout << temp[i][j] << "\t";
        }

        std::cout << "\n";
    }

    return;
}

void matrix::transposeMatrix() {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            temp[i][j] = grid[j][i];
        }
    }

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            std::cout << temp[i][j] << "\t";
        }

        std::cout << "\n";
    }

    return;
}

matrix::~matrix() {
    for (int i = 0; i < rows; i++) {
        delete[] grid[i];
        delete[] temp[i];
    }

    delete[] grid;
    delete[] temp;
}