#ifndef MATRIX_H
	#define MATRIX_H

	class matrix {
		int rows;
		int cols;

		double ** grid = nullptr;
		double ** temp = nullptr;

		public:
			void createMatrix();
			void printMatrix();
			void addMatrix();
			double getMax();
			bool findElement(int no);
			void changeElement(int r, int c, int no);
			void multiplyMatrix();
			void transposeMatrix();
			~matrix();
	};
#endif
